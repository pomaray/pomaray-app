import { Card, CardHeader, CardBody as CardContent } from "@nextui-org/react";
import { FaFacebook, FaLinkedin, FaTwitter } from 'react-icons/fa';

export default function Component() {
  return (
    <div className="flex flex-col min-h-screen bg-white">

      <main className="flex-1">
        <section className="relative w-full h-64 md:h-96 overflow-hidden -top-8">
          <img
            alt="Banner principal"
            className="absolute inset-0 object-cover w-full h-full"
            src="https://source.unsplash.com/1600x900/?nature,cat"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center text-center">
            <div className="text-white">
              <h2 className="text-2xl font-bold md:text-4xl">¡Noticia Importante!</h2>
              <button className="text-white bg-primaryhover:bg-green-700 px-4 py-2 mt-4">Leer más</button>
            </div>
          </div>
        </section>

        
        <h2 className="text-2xl font-bold md:text-4xl text-center py-5 text-primary first-letter:">¡Noticias destacadas!</h2>
        <section className="grid gap-6 p-6 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, index) => (
            <Card key={index}>
              <CardHeader>
                <h1>Noticia destacada {index + 1}</h1>
              </CardHeader>
              <CardContent>
                <img
                  alt={`Noticia destacada ${index + 1}`}
                  className="w-full h-40 object-cover"
                  src="https://scontent.fhex4-2.fna.fbcdn.net/v/t39.30808-6/411550531_722458286529551_261955699477084031_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=dd5e9f&_nc_eui2=AeFQar4YwrdfGKng_8YrrCIqtYyKoJjbBlC1jIqgmNsGUEhEWb9rzxLxyAyh4LRcQXhArsyDgaZEOdNHfn0PoB65&_nc_ohc=rm0y1DXfaP0AX969Ngv&_nc_oc=AQmrv6INVKJzy7ddSGdKdUwsqoO-tqvEjsair1TPt-C0n4eJO6zxTbpkpcesf5FyyB8&_nc_ht=scontent.fhex4-2.fna&oh=00_AfAPxvNHsv0awv6Th3XeNNGqgEZ823UCCcYRMKhSAmEMVA&oe=659B33A6"
                />
              </CardContent>
            </Card>
          ))}
        </section>

        {/* Sección de categorías */}
        <section className="grid gap-6 p-6 md:grid-cols-2 lg:grid-cols-3">
          {["Investigación", "Eventos", "Anuncios"].map((categoria, index) => (
            <Card key={index}>
              <CardHeader>
                <h1>{categoria}</h1>
              </CardHeader>
              <CardContent>
                <img
                  alt={categoria}
                  className="w-full h-40 object-cover"
                  src={`https://source.unsplash.com/800x600/?${categoria.toLowerCase()}`}
                />
              </CardContent>
            </Card>
          ))}
        </section>

        <section className="p-6">
          <h2 className="text-2xl font-bold mb-6">Noticias recientes</h2>
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="flex gap-4 mb-6">
              <img
                alt={`Noticia ${index + 1}`}
                className="w-32 h-32 object-cover"
                src="https://scontent.fhex4-2.fna.fbcdn.net/v/t39.30808-6/405985983_712071980901515_7694028336363065516_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=a73e89&_nc_eui2=AeESvxHaLpe8LKl4wtrIGIcLbHtkm8wrW5dse2SbzCtblwSIQKPWuLNcMouBgRDbqGKbo9_aUWYtmULpchRwZgBy&_nc_ohc=zFc29e2_7HUAX-9EFMV&_nc_ht=scontent.fhex4-2.fna&oh=00_AfC4MAexI0WaC7gQZrpdNVnDxqTvpj2nZEnHoacA2F60-Q&oe=659B6CD6"
              />
              <div className="space-y-2">
                <h3 className="text-lg font-bold">Noticia {index + 4}</h3>
                <p className="text-gray-500">Fecha</p>
                <p className="line-clamp-2">Resumen de la noticia...</p>
                <a className="text-primaryhover:text-green-700" href="#">
                  Leer más
                </a>
              </div>
            </div>
          ))}
        </section>
      </main>

      {/* Barra lateral de redes sociales */}
      <aside className="fixed bottom-4 right-4 flex flex-col gap-2">
        <button className="rounded-full bg-primaryhover:bg-green-700 p-2">
          <FaFacebook className="w-4 h-4 text-white" />
        </button>
        <button className="rounded-full bg-primaryhover:bg-green-700 p-2">
          <FaTwitter className="w-4 h-4 text-white" />
        </button>
        <button className="rounded-full bg-primaryhover:bg-green-700 p-2">
          <FaLinkedin className="w-4 h-4 text-white" />
        </button>
      </aside>

    </div>
  );
}
