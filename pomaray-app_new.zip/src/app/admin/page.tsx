export default function AdminPage() {
  return (
    <main>
      Admin
    </main>
  )
}