export const metadata = {
    title: "Anuario"
}

export default function LoginLayout({
    children
}: {
    children: React.ReactNode
}) {
    return (
        children
    )
}