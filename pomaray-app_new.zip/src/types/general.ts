export enum Sex {
    Male = "Male",
    Female = "Female",
    Other = "Other",
}
