export enum Tech {
  DAAI = "Desarrollo y Administración de Aplicaciones Informáticas",
  GAT = "Gestión Administrativa y Tributaria",
  CM = "Comercio y Mercadeo",
  TRO = "Electrónica",
  TRI = "Electricidad",
  RAE = "Refrigeración y Acondicionamiento de Aire",
  GAS = "Gastronomía",
}
