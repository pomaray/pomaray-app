"use client";

const Sidebar = () => {

  return (
    <div>Sidebar</div>
  );
};

export default Sidebar;
